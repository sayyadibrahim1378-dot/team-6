"""
pipeline/pipeline_sim.py

5-Stage Pipeline Simulator (IF, ID, EX, MEM, WB) with:
  - Data hazard detection (RAW)
  - Forwarding (EX/MEM -> EX, MEM/WB -> EX)
  - Load-use hazard stalling
  - Simple static branch (always-not-taken) with flush-on-mispredict option

Used for: Task 1 -- Pipeline Analysis (CSA12 assignment)
"""

from dataclasses import dataclass, field
from typing import List, Optional


@dataclass
class Instruction:
    text: str
    op: str
    rd: Optional[str] = None
    rs1: Optional[str] = None
    rs2: Optional[str] = None
    is_load: bool = False
    is_branch: bool = False

    def __repr__(self):
        return self.text


STAGES = ["IF", "ID", "EX", "MEM", "WB"]


class PipelineSimulator:
    """
    Simulates a classic 5-stage in-order pipeline.

    forwarding=True  -> EX/MEM and MEM/WB results are forwarded to EX,
                         eliminating most RAW stalls except load-use hazards.
    forwarding=False -> No forwarding; RAW hazards always stall until the
                         producing instruction reaches WB.
    """

    def __init__(self, instructions: List[Instruction], forwarding: bool = True):
        self.instructions = instructions
        self.forwarding = forwarding
        self.n = len(instructions)
        # timeline[i] = list of (cycle, stage) the i-th instruction occupied
        self.timeline: List[List[Optional[str]]] = []
        self.stall_cycles = 0
        self.total_cycles = 0

    def _reads(self, instr: Instruction):
        return [r for r in (instr.rs1, instr.rs2) if r is not None]

    def run(self, max_cycles: int = 500):
        """
        Cycle-by-cycle simulation. Each instruction's stage-occupancy per
        cycle is recorded so a timing diagram can be printed/exported.
        """
        # in_stage[i] = current stage index of instruction i, or None if not yet issued
        in_stage = [None] * self.n
        completed = [False] * self.n
        schedule = [[] for _ in range(self.n)]

        cycle = 0
        next_to_fetch = 0
        # track which instr occupies each stage this cycle for hazard checks
        stage_occupant = {s: None for s in STAGES}

        while not all(completed) and cycle < max_cycles:
            cycle += 1
            new_occupant = {s: None for s in STAGES}

            # Determine advancement in reverse pipeline order (WB->MEM->EX->ID->IF)
            # to avoid one instruction skipping two stages in a single cycle.
            prev_occupant = stage_occupant

            # WB: whichever instr was in MEM last cycle moves to WB
            if prev_occupant["MEM"] is not None:
                i = prev_occupant["MEM"]
                new_occupant["WB"] = i

            # MEM: whichever instr was in EX last cycle moves to MEM
            if prev_occupant["EX"] is not None:
                i = prev_occupant["EX"]
                new_occupant["MEM"] = i

            # EX: instr in ID moves to EX, UNLESS a hazard forces it to stay/stall
            stalled_in_id = False
            if prev_occupant["ID"] is not None:
                i = prev_occupant["ID"]
                instr = self.instructions[i]
                needed_regs = self._reads(instr)

                producer_in_ex = prev_occupant["EX"]
                producer_in_mem = prev_occupant["MEM"]

                hazard = False
                # Load-use hazard: producer is a load currently in EX
                # (its data isn't ready even with forwarding until after MEM)
                if producer_in_ex is not None:
                    p = self.instructions[producer_in_ex]
                    if p.rd in needed_regs and p.rd is not None:
                        if p.is_load:
                            hazard = True  # must stall 1 cycle even with forwarding
                        elif not self.forwarding:
                            hazard = True  # no forwarding at all -> stall

                if not hazard and producer_in_mem is not None:
                    p = self.instructions[producer_in_mem]
                    if p.rd in needed_regs and p.rd is not None:
                        if not self.forwarding:
                            hazard = True

                if hazard:
                    stalled_in_id = True
                    self.stall_cycles += 1
                    new_occupant["EX"] = None
                else:
                    new_occupant["EX"] = i

            # ID: instr in IF moves to ID, unless ID is still occupied by a stalled instr
            if stalled_in_id:
                new_occupant["ID"] = prev_occupant["ID"]  # stays put
                new_occupant["IF"] = prev_occupant["IF"]  # IF also stalls (structural)
            else:
                if prev_occupant["IF"] is not None:
                    new_occupant["ID"] = prev_occupant["IF"]
                # IF: fetch next instruction if available
                if next_to_fetch < self.n:
                    new_occupant["IF"] = next_to_fetch
                    next_to_fetch += 1
                else:
                    new_occupant["IF"] = None

            # Record occupancy for this cycle & mark completion
            for s in STAGES:
                idx = new_occupant[s]
                if idx is not None:
                    while len(schedule[idx]) < cycle:
                        schedule[idx].append(None)
                    schedule[idx][cycle - 1] = s
            if new_occupant["WB"] is not None:
                completed[new_occupant["WB"]] = True

            stage_occupant = new_occupant

        self.timeline = schedule
        self.total_cycles = cycle
        return self.summary()

    def summary(self):
        ideal_cycles = len(STAGES) + self.n - 1
        cpi = self.total_cycles / self.n if self.n else 0
        return {
            "instructions": self.n,
            "total_cycles": self.total_cycles,
            "ideal_cycles_no_hazards": ideal_cycles,
            "stall_cycles": self.stall_cycles,
            "cpi": round(cpi, 3),
            "forwarding_enabled": self.forwarding,
        }

    def print_diagram(self):
        header = "Instr".ljust(20) + "".join(f"C{c+1:<4}" for c in range(self.total_cycles))
        print(header)
        for i, instr in enumerate(self.instructions):
            row = str(instr).ljust(20)
            for c in range(self.total_cycles):
                stage = self.timeline[i][c] if c < len(self.timeline[i]) else None
                row += (stage or "").ljust(5)
            print(row)


def demo():
    # Matches the worked example in the assignment report:
    # I1: ADD R1,R2,R3
    # I2: SUB R4,R1,R5   (RAW hazard on R1)
    # I3: AND R6,R1,R7   (RAW hazard on R1)
    instrs = [
        Instruction("I1: ADD R1,R2,R3", "ADD", rd="R1", rs1="R2", rs2="R3"),
        Instruction("I2: SUB R4,R1,R5", "SUB", rd="R4", rs1="R1", rs2="R5"),
        Instruction("I3: AND R6,R1,R7", "AND", rd="R6", rs1="R1", rs2="R7"),
    ]

    print("=== WITHOUT forwarding ===")
    sim_no_fwd = PipelineSimulator(instrs, forwarding=False)
    print(sim_no_fwd.run())
    sim_no_fwd.print_diagram()

    print("\n=== WITH forwarding ===")
    sim_fwd = PipelineSimulator(instrs, forwarding=True)
    print(sim_fwd.run())
    sim_fwd.print_diagram()


if __name__ == "__main__":
    demo()
