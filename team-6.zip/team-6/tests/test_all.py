"""
tests/test_all.py

Basic correctness tests for each simulator module.
Run with: python3 -m pytest tests/ -v   (or) python3 tests/test_all.py
"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from pipeline.pipeline_sim import PipelineSimulator, Instruction
from cache.cache_sim import Cache, MemoryHierarchy
from virtual_memory.tlb_sim import TLB, PageTable, VirtualMemorySystem
from io_dma.io_sim import simulate_programmed_io, simulate_interrupt_driven_io, simulate_dma
from bus.disk_scheduling import fcfs, sstf, scan, c_scan


def test_pipeline_no_forwarding_has_more_stalls_than_with_forwarding():
    instrs = [
        Instruction("I1", "ADD", rd="R1", rs1="R2", rs2="R3"),
        Instruction("I2", "SUB", rd="R4", rs1="R1", rs2="R5"),
    ]
    no_fwd = PipelineSimulator(instrs, forwarding=False)
    no_fwd.run()
    fwd = PipelineSimulator(instrs, forwarding=True)
    fwd.run()
    assert no_fwd.stall_cycles >= fwd.stall_cycles
    assert fwd.total_cycles <= no_fwd.total_cycles
    print("test_pipeline_no_forwarding_has_more_stalls_than_with_forwarding: PASS")


def test_pipeline_no_hazard_hits_ideal_cycle_count():
    instrs = [
        Instruction("I1", "ADD", rd="R1", rs1="R2", rs2="R3"),
        Instruction("I2", "ADD", rd="R4", rs1="R5", rs2="R6"),
        Instruction("I3", "ADD", rd="R7", rs1="R8", rs2="R9"),
    ]
    sim = PipelineSimulator(instrs, forwarding=True)
    result = sim.run()
    assert result["total_cycles"] == result["ideal_cycles_no_hazards"]
    assert result["stall_cycles"] == 0
    print("test_pipeline_no_hazard_hits_ideal_cycle_count: PASS")


def test_cache_hit_after_first_access():
    c = Cache("L1", size_bytes=1024, block_size=64, associativity=4, hit_time_cycles=1)
    assert c.access(0) is False   # first access -> miss
    assert c.access(0) is True    # second access to same block -> hit
    print("test_cache_hit_after_first_access: PASS")


def test_cache_lru_eviction():
    # 1 set, 2-way associative -> only 2 blocks can be resident at once
    c = Cache("L1", size_bytes=128, block_size=64, associativity=2, hit_time_cycles=1)
    c.access(0)          # block 0 in
    c.access(64)         # block 1 in
    c.access(128)        # block 2 in -> evicts LRU (block 0)
    assert c.access(0) is False   # block 0 was evicted -> miss again
    print("test_cache_lru_eviction: PASS")


def test_memory_hierarchy_reduces_latency_with_higher_hit_ratio():
    l1 = Cache("L1", size_bytes=1024, block_size=64, associativity=4, hit_time_cycles=1)
    hierarchy = MemoryHierarchy([l1], main_memory_cycles=100)
    trace_repeated = [0] * 100  # perfect locality
    result = hierarchy.run_trace(trace_repeated)
    assert result["effective_access_time_cycles"] < 100
    print("test_memory_hierarchy_reduces_latency_with_higher_hit_ratio: PASS")


def test_tlb_hit_after_first_translation():
    tlb = TLB(num_entries=4)
    pt = PageTable(page_table_access_cycles=50)
    vms = VirtualMemorySystem(tlb, pt, main_memory_cycles=50, page_fault_rate=0.0)
    next_pfn = [0]
    def alloc():
        next_pfn[0] += 1
        return next_pfn[0]
    vms.translate_and_access(5, alloc)
    vms.translate_and_access(5, alloc)
    assert tlb.hits == 1
    assert tlb.misses == 1
    print("test_tlb_hit_after_first_translation: PASS")


def test_dma_uses_far_fewer_cpu_instructions_than_programmed_io():
    n = 1000
    prog = simulate_programmed_io(n)
    dma = simulate_dma(n)
    assert dma.total_cpu_instructions < prog.total_cpu_instructions
    assert dma.cpu_free_cycles > prog.cpu_free_cycles
    print("test_dma_uses_far_fewer_cpu_instructions_than_programmed_io: PASS")


def test_disk_scheduling_scan_beats_fcfs_on_scattered_requests():
    requests = [98, 183, 37, 122, 14, 124, 65, 67]
    head = 53
    f = fcfs(requests, head)
    s = scan(requests, head, disk_size=200)
    assert s["total_head_movement"] < f["total_head_movement"]
    print("test_disk_scheduling_scan_beats_fcfs_on_scattered_requests: PASS")


def test_disk_scheduling_sstf_matches_known_value():
    requests = [98, 183, 37, 122, 14, 124, 65, 67]
    head = 53
    result = sstf(requests, head)
    assert result["total_head_movement"] == 236
    print("test_disk_scheduling_sstf_matches_known_value: PASS")


def run_all():
    tests = [v for k, v in globals().items() if k.startswith("test_") and callable(v)]
    for t in tests:
        t()
    print(f"\nAll {len(tests)} tests passed.")


if __name__ == "__main__":
    run_all()
