"""
run_all.py

Single entry point that runs every simulator and prints a consolidated
report -- this is the "Implementation / Simulation Results" evidence
referenced in the CSA12 written assignment solution.

Usage:
    python3 run_all.py
"""

import json

from pipeline.pipeline_sim import PipelineSimulator, Instruction
from cache.cache_sim import Cache, MemoryHierarchy
from virtual_memory.tlb_sim import TLB, PageTable, VirtualMemorySystem
from io_dma.io_sim import compare_io_modes
from bus.disk_scheduling import compare_all as compare_disk_scheduling


def section(title):
    print("\n" + "=" * 70)
    print(title)
    print("=" * 70)


def run_pipeline():
    section("TASK 1 -- PIPELINE HAZARD & FORWARDING SIMULATION")
    instrs = [
        Instruction("I1: ADD R1,R2,R3", "ADD", rd="R1", rs1="R2", rs2="R3"),
        Instruction("I2: SUB R4,R1,R5", "SUB", rd="R4", rs1="R1", rs2="R5"),
        Instruction("I3: AND R6,R1,R7", "AND", rd="R6", rs1="R1", rs2="R7"),
    ]
    for fwd in (False, True):
        sim = PipelineSimulator(instrs, forwarding=fwd)
        result = sim.run()
        print(f"\nForwarding = {fwd}")
        print(json.dumps(result, indent=2))
        sim.print_diagram()


def run_cache():
    section("TASK 2 -- CACHE HIERARCHY SIMULATION (L1/L2/L3)")
    import random
    random.seed(42)

    l1 = Cache("L1", size_bytes=32 * 1024, block_size=64, associativity=4, hit_time_cycles=1)
    l2 = Cache("L2", size_bytes=256 * 1024, block_size=64, associativity=8, hit_time_cycles=10)
    l3 = Cache("L3", size_bytes=8 * 1024 * 1024, block_size=64, associativity=16, hit_time_cycles=35)
    hierarchy = MemoryHierarchy([l1, l2, l3], main_memory_cycles=150)

    working_set = [i * 64 for i in range(200)]
    cold_region = [i * 64 for i in range(200, 200000)]
    trace = []
    for _ in range(20000):
        trace.append(random.choice(working_set) if random.random() < 0.9 else random.choice(cold_region))

    result = hierarchy.run_trace(trace)
    print(json.dumps(result, indent=2))
    print("Theoretical EAT (report closed-form):", hierarchy.theoretical_eat(), "cycles")


def run_virtual_memory():
    section("TASK 3 -- TLB / VIRTUAL MEMORY SIMULATION")
    import random
    random.seed(7)

    tlb = TLB(num_entries=64, access_time_cycles=1)
    pt = PageTable(page_table_access_cycles=100)
    vms = VirtualMemorySystem(tlb, pt, main_memory_cycles=100,
                               page_fault_service_cycles=8_000_000,
                               page_fault_rate=0.00001)

    working_set = list(range(50))
    trace = []
    for _ in range(5000):
        trace.append(random.choice(working_set) if random.random() < 0.95 else random.randint(51, 5000))

    result = vms.run_trace(trace)
    print(json.dumps(result, indent=2))

    theoretical = VirtualMemorySystem.theoretical_emat(
        tlb_hit_ratio=0.97, tlb_time=1, page_table_time=100,
        mem_time=100, page_fault_rate=0.00001, page_fault_service_time=8_000_000
    )
    print("Theoretical EMAT (report closed-form):", theoretical, "cycles")


def run_io_dma():
    section("TASK 4 -- I/O MODE COMPARISON (Programmed / Interrupt / DMA)")
    num_words = (1 * 1024 * 1024) // 4  # 1 MB transfer, 4-byte words
    results = compare_io_modes(num_words)
    print(f"{'Mode':<22}{'CPU Instrs':<14}{'Total Cycles':<16}{'CPU Busy':<12}{'CPU Free':<12}{'CPU Free %'}")
    for r in results:
        print(f"{r.mode:<22}{r.total_cpu_instructions:<14}{r.total_transfer_cycles:<16}"
              f"{r.cpu_busy_cycles:<12}{r.cpu_free_cycles:<12}{r.cpu_utilization_pct()}")


def run_disk_scheduling():
    section("TASK 5 -- DISK SCHEDULING COMPARISON (FCFS / SSTF / SCAN / C-SCAN)")
    requests = [98, 183, 37, 122, 14, 124, 65, 67]
    head_start = 53
    results = compare_disk_scheduling(requests, head_start, disk_size=200)
    for r in results:
        print(f"{r['algorithm']:<10} order={r['service_order']}  "
              f"total_head_movement={r['total_head_movement']} cylinders")


if __name__ == "__main__":
    run_pipeline()
    run_cache()
    run_virtual_memory()
    run_io_dma()
    run_disk_scheduling()
    print("\nAll simulations complete.")
