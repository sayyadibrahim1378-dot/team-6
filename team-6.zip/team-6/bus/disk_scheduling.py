"""
bus/disk_scheduling.py

Implements and compares disk-scheduling algorithms:
  - FCFS (First-Come-First-Served)
  - SSTF (Shortest Seek Time First)
  - SCAN (elevator algorithm)
  - C-SCAN (circular SCAN)

Used for: Task 5 -- Bus Organization & I/O Performance Optimization,
and Section (c) File System / Disk Scheduling discussion.
"""

from typing import List


def fcfs(requests: List[int], head_start: int) -> dict:
    order = [head_start] + requests
    total_movement = sum(abs(order[i + 1] - order[i]) for i in range(len(order) - 1))
    return {"algorithm": "FCFS", "service_order": requests, "total_head_movement": total_movement}


def sstf(requests: List[int], head_start: int) -> dict:
    remaining = requests.copy()
    current = head_start
    order = []
    total_movement = 0
    while remaining:
        nearest = min(remaining, key=lambda r: abs(r - current))
        total_movement += abs(nearest - current)
        current = nearest
        order.append(nearest)
        remaining.remove(nearest)
    return {"algorithm": "SSTF", "service_order": order, "total_head_movement": total_movement}


def scan(requests: List[int], head_start: int, disk_size: int, direction: str = "up") -> dict:
    """
    LOOK variant of SCAN: sweep toward one end but reverse as soon as the
    last request in that direction is served (does not travel all the way
    to the physical disk edge if no request lies there).
    """
    req_sorted = sorted(requests)
    larger = [r for r in req_sorted if r >= head_start]
    smaller = [r for r in req_sorted if r < head_start]

    if direction == "up":
        order = larger + list(reversed(smaller))
    else:
        order = list(reversed(smaller)) + larger

    total_movement = 0
    current = head_start
    for r in order:
        total_movement += abs(r - current)
        current = r

    return {"algorithm": "SCAN", "service_order": order, "total_head_movement": total_movement}


def c_scan(requests: List[int], head_start: int, disk_size: int) -> dict:
    """Circular SCAN: sweep up to the end, jump back to 0, continue sweeping up."""
    req_sorted = sorted(requests)
    larger = [r for r in req_sorted if r >= head_start]
    smaller = [r for r in req_sorted if r < head_start]

    order = larger + [disk_size - 1, 0] + smaller
    total_movement = 0
    current = head_start
    for r in order:
        total_movement += abs(r - current)
        current = r

    order = [r for r in order if r in requests]
    return {"algorithm": "C-SCAN", "service_order": order, "total_head_movement": total_movement}


def compare_all(requests: List[int], head_start: int, disk_size: int = 200):
    return [
        fcfs(requests, head_start),
        sstf(requests, head_start),
        scan(requests, head_start, disk_size, direction="up"),
        c_scan(requests, head_start, disk_size),
    ]


def demo():
    # Matches the worked example in the written report
    requests = [98, 183, 37, 122, 14, 124, 65, 67]
    head_start = 53

    results = compare_all(requests, head_start, disk_size=200)
    for r in results:
        print(f"{r['algorithm']:<10} order={r['service_order']}  "
              f"total_head_movement={r['total_head_movement']} cylinders")


if __name__ == "__main__":
    demo()
