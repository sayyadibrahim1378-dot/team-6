"""
io_dma/io_sim.py

Simulates and compares three I/O transfer mechanisms:
  - Programmed I/O (busy-wait, CPU issues an instruction per word)
  - Interrupt-driven I/O (CPU does other work, interrupted per word/block)
  - DMA (CPU issues one setup + handles one completion interrupt per block)

Used for: Task 4 -- I/O and DMA (CSA12 assignment)
"""

from dataclasses import dataclass


@dataclass
class IOResult:
    mode: str
    total_cpu_instructions: int
    total_transfer_cycles: int
    cpu_busy_cycles: int
    cpu_free_cycles: int

    def cpu_utilization_pct(self):
        """Percentage of total transfer wall-clock time the CPU is FREE for other work."""
        total = self.total_transfer_cycles
        return round(100 * self.cpu_free_cycles / total, 2) if total else 0.0


def simulate_programmed_io(num_words: int, cycles_per_word_transfer: int = 4,
                            poll_overhead_cycles: int = 2) -> IOResult:
    """CPU busy-waits and issues one transfer instruction per word."""
    cpu_instructions = num_words  # one instruction (load/store) per word
    total_cycles = num_words * (cycles_per_word_transfer + poll_overhead_cycles)
    return IOResult(
        mode="Programmed I/O",
        total_cpu_instructions=cpu_instructions,
        total_transfer_cycles=total_cycles,
        cpu_busy_cycles=total_cycles,   # CPU fully occupied the whole time
        cpu_free_cycles=0,
    )


def simulate_interrupt_driven_io(num_words: int, cycles_per_word_transfer: int = 4,
                                  interrupt_overhead_cycles: int = 2) -> IOResult:
    """CPU is interrupted once per word; does other work between interrupts."""
    cpu_instructions = num_words  # one ISR invocation per word
    busy = num_words * interrupt_overhead_cycles
    transfer = num_words * cycles_per_word_transfer
    total_cycles = max(transfer, busy)
    free = max(total_cycles - busy, 0)
    return IOResult(
        mode="Interrupt-driven I/O",
        total_cpu_instructions=cpu_instructions,
        total_transfer_cycles=total_cycles,
        cpu_busy_cycles=busy,
        cpu_free_cycles=free,
    )


def simulate_dma(num_words: int, cycles_per_word_transfer: int = 4,
                  setup_overhead_cycles: int = 30,
                  completion_interrupt_cycles: int = 30) -> IOResult:
    """CPU issues one setup instruction sequence, then is free until completion."""
    cpu_instructions = 2  # start() + handle_completion_interrupt()
    busy = setup_overhead_cycles + completion_interrupt_cycles
    transfer = num_words * cycles_per_word_transfer  # happens off the CPU critical path
    total_cycles = max(transfer, busy)
    free = max(total_cycles - busy, 0)
    return IOResult(
        mode="DMA",
        total_cpu_instructions=cpu_instructions,
        total_transfer_cycles=total_cycles,
        cpu_busy_cycles=busy,
        cpu_free_cycles=free,
    )


def compare_io_modes(num_words: int):
    results = [
        simulate_programmed_io(num_words),
        simulate_interrupt_driven_io(num_words),
        simulate_dma(num_words),
    ]
    return results


def demo():
    # 1 MB transfer, 4 bytes/word -> 262144 words (matches report's 1 MB example)
    num_words = (1 * 1024 * 1024) // 4
    results = compare_io_modes(num_words)

    print(f"{'Mode':<22}{'CPU Instrs':<14}{'Total Cycles':<16}{'CPU Busy':<12}{'CPU Free':<12}{'CPU Free %'}")
    for r in results:
        print(f"{r.mode:<22}{r.total_cpu_instructions:<14}{r.total_transfer_cycles:<16}"
              f"{r.cpu_busy_cycles:<12}{r.cpu_free_cycles:<12}{r.cpu_utilization_pct()}")


if __name__ == "__main__":
    demo()
