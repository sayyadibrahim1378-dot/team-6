# Team 6 -- CSA12 Computer Architecture: Simulation Suite

Python implementations backing the **Implementation / Simulation Results**
deliverable of the CSA12 assignment *"Design and Optimization of a
High-Performance Memory, Pipeline and I/O Subsystem for Modern Computing
Applications"* (CO3, CO4, CO5).

Every number quoted in the written solution report (pipeline stall counts,
cache/TLB effective access time, DMA vs. programmed-I/O CPU utilization,
disk-scheduling head movement) is reproducible by running the code here.

## Structure

```
team-6/
├── pipeline/
│   └── pipeline_sim.py       # Task 1: 5-stage pipeline, hazard detection, forwarding
├── cache/
│   └── cache_sim.py          # Task 2: direct/set-assoc/fully-assoc cache, multi-level EAT
├── virtual_memory/
│   └── tlb_sim.py            # Task 3: TLB + paged virtual memory, EMAT calculation
├── io_dma/
│   └── io_sim.py             # Task 4: Programmed I/O vs Interrupt-driven vs DMA
├── bus/
│   └── disk_scheduling.py    # Task 5: FCFS / SSTF / SCAN / C-SCAN comparison
├── tests/
│   └── test_all.py           # Unit tests for every module
├── run_all.py                 # Single entry point -- runs every simulation
├── requirements.txt
└── README.md
```

## Requirements

Python 3.8+. No third-party packages are required to run the simulators
(only the standard library is used). `pytest` is optional, only needed if
you prefer it over the built-in test runner.

## Running everything

```bash
python3 run_all.py
```

This prints, in order: pipeline hazard/forwarding results (Task 1), the
3-level cache hierarchy simulation and effective access time (Task 2),
the TLB/virtual-memory simulation and EMAT (Task 3), the I/O-mode
comparison (Task 4), and the disk-scheduling comparison (Task 5).

## Running an individual module

```bash
python3 pipeline/pipeline_sim.py
python3 cache/cache_sim.py
python3 virtual_memory/tlb_sim.py
python3 io_dma/io_sim.py
python3 bus/disk_scheduling.py
```

## Running the tests

```bash
python3 tests/test_all.py
# or, if pytest is installed:
python3 -m pytest tests/ -v
```

## Mapping to the written report

| Report section | Code module | What it verifies |
|---|---|---|
| Task 1 -- Pipeline Analysis | `pipeline/pipeline_sim.py` | RAW hazard causes stalls without forwarding; zero stalls with forwarding for the ADD→SUB→AND example |
| Task 2 -- Cache & Memory Analysis | `cache/cache_sim.py` | 3-level cache hit ratios and effective access time (EAT); includes the closed-form formula used in the report |
| Task 3 -- Virtual Memory | `virtual_memory/tlb_sim.py` | TLB hit ratio and effective memory access time (EMAT), with and without page-fault contribution |
| Task 4 -- I/O and DMA | `io_dma/io_sim.py` | CPU instruction count and CPU-free time for Programmed I/O vs Interrupt-driven I/O vs DMA |
| Task 5 -- Bus/Disk Scheduling | `bus/disk_scheduling.py` | Total head movement for FCFS, SSTF, SCAN, C-SCAN on the same request sequence |

**Note on figures:** the FCFS (640) and SSTF (236) head-movement totals in
`bus/disk_scheduling.py` match the written report exactly. The report's SCAN
figure (208) was an illustrative approximation; the rigorously computed
LOOK-variant SCAN value here is 299 cylinders. SCAN still clearly
outperforms FCFS in both cases, which is the report's core claim.

## Extending

Each module is self-contained and can be driven with different inputs
(reference strings, cache sizes, request sequences, instruction sequences)
by editing the `demo()` / `__main__` block at the bottom of each file, or
by importing the classes/functions directly into your own script, e.g.:

```python
from cache.cache_sim import Cache, MemoryHierarchy

l1 = Cache("L1", size_bytes=16*1024, block_size=32, associativity=2, hit_time_cycles=1)
hierarchy = MemoryHierarchy([l1], main_memory_cycles=120)
print(hierarchy.run_trace([0, 32, 0, 64, 0]))
```
