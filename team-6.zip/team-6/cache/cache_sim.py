"""
cache/cache_sim.py

Configurable cache simulator supporting:
  - Direct-mapped, set-associative (n-way), and fully-associative mapping
  - LRU replacement policy
  - Multi-level hierarchy (L1 -> L2 -> L3 -> main memory)
  - Effective Access Time (EAT) calculation

Used for: Task 2 -- Cache and Memory Analysis (CSA12 assignment)
"""

from collections import OrderedDict
from dataclasses import dataclass
from typing import List, Optional


class Cache:
    def __init__(self, name: str, size_bytes: int, block_size: int,
                 associativity: int, hit_time_cycles: int):
        """
        associativity=1            -> direct mapped
        associativity=num_lines    -> fully associative
        1 < associativity < lines  -> n-way set associative
        """
        self.name = name
        self.block_size = block_size
        self.hit_time = hit_time_cycles
        self.num_lines = size_bytes // block_size
        self.associativity = min(associativity, self.num_lines)
        self.num_sets = self.num_lines // self.associativity

        # sets[set_index] = OrderedDict{tag: True}, ordered by recency (LRU at front)
        self.sets = [OrderedDict() for _ in range(self.num_sets)]

        self.accesses = 0
        self.hits = 0
        self.misses = 0

    def _decompose(self, address: int):
        block_addr = address // self.block_size
        set_index = block_addr % self.num_sets
        tag = block_addr // self.num_sets
        return set_index, tag

    def access(self, address: int) -> bool:
        """Returns True on hit, False on miss. Updates LRU state either way."""
        self.accesses += 1
        set_index, tag = self._decompose(address)
        cache_set = self.sets[set_index]

        if tag in cache_set:
            self.hits += 1
            cache_set.move_to_end(tag)  # mark as most-recently-used
            return True

        # miss -> bring block in
        self.misses += 1
        if len(cache_set) >= self.associativity:
            cache_set.popitem(last=False)  # evict LRU (front of OrderedDict)
        cache_set[tag] = True
        return False

    def hit_ratio(self) -> float:
        return self.hits / self.accesses if self.accesses else 0.0

    def stats(self):
        return {
            "name": self.name,
            "accesses": self.accesses,
            "hits": self.hits,
            "misses": self.misses,
            "hit_ratio": round(self.hit_ratio(), 4),
            "num_sets": self.num_sets,
            "associativity": self.associativity,
        }


class MemoryHierarchy:
    """
    Chains multiple cache levels in front of main memory and computes
    Effective Access Time (EAT) for a given access trace.
    """

    def __init__(self, levels: List[Cache], main_memory_cycles: int):
        self.levels = levels
        self.mem_cycles = main_memory_cycles

    def access(self, address: int) -> int:
        """Simulate one memory access through the hierarchy; return latency in cycles."""
        latency = 0
        for level in self.levels:
            latency += level.hit_time
            if level.access(address):
                return latency
        # missed every level -> pay main memory latency too
        latency += self.mem_cycles
        return latency

    def run_trace(self, addresses: List[int]) -> dict:
        total_latency = 0
        for addr in addresses:
            total_latency += self.access(addr)
        eat = total_latency / len(addresses) if addresses else 0
        return {
            "num_accesses": len(addresses),
            "total_latency_cycles": total_latency,
            "effective_access_time_cycles": round(eat, 3),
            "levels": [lvl.stats() for lvl in self.levels],
        }

    def theoretical_eat(self) -> float:
        """
        Closed-form EAT using each level's *measured* hit ratio so far,
        matching the formula used in the written report:
        EAT = H1*T1 + (1-H1)*[H2*T2 + (1-H2)*(H3*T3 + (1-H3)*Tmem)]
        Assumes exactly 3 cache levels for this helper (as in the report).
        """
        if len(self.levels) != 3:
            raise ValueError("theoretical_eat() helper assumes exactly 3 cache levels")
        l1, l2, l3 = self.levels
        h1, h2, h3 = l1.hit_ratio(), l2.hit_ratio(), l3.hit_ratio()
        t1, t2, t3 = l1.hit_time, l2.hit_time, l3.hit_time
        eat = h1 * t1 + (1 - h1) * (h2 * t2 + (1 - h2) * (h3 * t3 + (1 - h3) * self.mem_cycles))
        return round(eat, 3)


def demo():
    # 3-level hierarchy matching the report's worked example parameters
    l1 = Cache("L1", size_bytes=32 * 1024, block_size=64, associativity=4, hit_time_cycles=1)
    l2 = Cache("L2", size_bytes=256 * 1024, block_size=64, associativity=8, hit_time_cycles=10)
    l3 = Cache("L3", size_bytes=8 * 1024 * 1024, block_size=64, associativity=16, hit_time_cycles=35)

    hierarchy = MemoryHierarchy([l1, l2, l3], main_memory_cycles=150)

    # Synthetic trace with locality: repeated access to a working set of
    # 200 blocks, with occasional accesses to a much larger "cold" region.
    import random
    random.seed(42)
    working_set = [i * 64 for i in range(200)]
    cold_region = [i * 64 for i in range(200, 200000)]

    trace = []
    for _ in range(20000):
        if random.random() < 0.9:
            trace.append(random.choice(working_set))
        else:
            trace.append(random.choice(cold_region))

    result = hierarchy.run_trace(trace)
    import json
    print(json.dumps(result, indent=2))
    print("Theoretical EAT (report formula):", hierarchy.theoretical_eat(), "cycles")


if __name__ == "__main__":
    demo()
