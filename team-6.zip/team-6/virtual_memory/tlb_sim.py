"""
virtual_memory/tlb_sim.py

Simulates paged virtual memory address translation with a TLB:
  - TLB (fully-associative, LRU) for fast virtual->physical translation
  - Page table walk on TLB miss
  - Page fault simulation with configurable fault rate/service time
  - Effective Memory Access Time (EMAT) calculation

Used for: Task 3 -- Virtual Memory (CSA12 assignment)
"""

from collections import OrderedDict
import random


class TLB:
    def __init__(self, num_entries: int, access_time_cycles: int = 1):
        self.num_entries = num_entries
        self.access_time = access_time_cycles
        self.entries = OrderedDict()  # vpn -> pfn, LRU order
        self.hits = 0
        self.misses = 0

    def lookup(self, vpn: int):
        if vpn in self.entries:
            self.hits += 1
            self.entries.move_to_end(vpn)
            return self.entries[vpn]
        self.misses += 1
        return None

    def insert(self, vpn: int, pfn: int):
        if vpn in self.entries:
            self.entries.move_to_end(vpn)
            self.entries[vpn] = pfn
            return
        if len(self.entries) >= self.num_entries:
            self.entries.popitem(last=False)  # evict LRU
        self.entries[vpn] = pfn

    def hit_ratio(self):
        total = self.hits + self.misses
        return self.hits / total if total else 0.0


class PageTable:
    def __init__(self, page_table_access_cycles: int = 100):
        self.table = {}  # vpn -> pfn (present pages only)
        self.access_time = page_table_access_cycles

    def is_present(self, vpn: int) -> bool:
        return vpn in self.table

    def lookup(self, vpn: int):
        return self.table.get(vpn)

    def map_page(self, vpn: int, pfn: int):
        self.table[vpn] = pfn


class VirtualMemorySystem:
    def __init__(self, tlb: TLB, page_table: PageTable,
                 main_memory_cycles: int = 100,
                 page_fault_service_cycles: int = 8_000_000,
                 page_fault_rate: float = 0.0):
        """
        page_fault_rate: probability that a page-table miss also triggers
        a full page fault (page not resident, must be loaded from disk).
        """
        self.tlb = tlb
        self.page_table = page_table
        self.mem_cycles = main_memory_cycles
        self.pf_service_cycles = page_fault_service_cycles
        self.pf_rate = page_fault_rate

        self.total_accesses = 0
        self.page_faults = 0
        self.total_latency = 0

    def translate_and_access(self, vpn: int, next_pfn_allocator) -> int:
        """
        Simulates one memory access through TLB -> page table -> memory.
        next_pfn_allocator: callable returning a fresh physical frame number,
        used when a page must be newly mapped (first touch / after a fault).
        Returns latency in cycles.
        """
        self.total_accesses += 1
        latency = 0

        pfn = self.tlb.lookup(vpn)
        if pfn is not None:
            latency += self.tlb.access_time
            latency += self.mem_cycles  # actual data access
            return latency

        # TLB miss -> consult page table
        latency += self.tlb.access_time  # time spent checking TLB before miss
        latency += self.page_table.access_time

        if not self.page_table.is_present(vpn):
            # Simulate whether this is a genuine page fault
            if random.random() < self.pf_rate:
                self.page_faults += 1
                latency += self.pf_service_cycles
            pfn = next_pfn_allocator()
            self.page_table.map_page(vpn, pfn)
        else:
            pfn = self.page_table.lookup(vpn)

        self.tlb.insert(vpn, pfn)
        latency += self.mem_cycles  # actual data access after translation
        self.total_latency += latency
        return latency

    def run_trace(self, vpn_trace):
        next_pfn = [0]

        def allocator():
            next_pfn[0] += 1
            return next_pfn[0]

        total = 0
        for vpn in vpn_trace:
            total += self.translate_and_access(vpn, allocator)

        emat = total / len(vpn_trace) if vpn_trace else 0
        return {
            "num_accesses": len(vpn_trace),
            "tlb_hit_ratio": round(self.tlb.hit_ratio(), 4),
            "page_faults": self.page_faults,
            "total_latency_cycles": total,
            "effective_memory_access_time_cycles": round(emat, 3),
        }

    @staticmethod
    def theoretical_emat(tlb_hit_ratio, tlb_time, page_table_time,
                          mem_time, page_fault_rate, page_fault_service_time):
        """
        Closed-form EMAT matching the formula used in the written report:
        EMAT = H_tlb*(T_tlb + T_mem) + (1-H_tlb)*(T_tlb + T_pt + T_mem)
               + page_fault_rate * page_fault_service_time
        """
        h = tlb_hit_ratio
        base = h * (tlb_time + mem_time) + (1 - h) * (tlb_time + page_table_time + mem_time)
        with_faults = base + page_fault_rate * page_fault_service_time
        return round(with_faults, 3)


def demo():
    random.seed(7)
    tlb = TLB(num_entries=64, access_time_cycles=1)
    pt = PageTable(page_table_access_cycles=100)
    vms = VirtualMemorySystem(
        tlb=tlb,
        page_table=pt,
        main_memory_cycles=100,
        page_fault_service_cycles=8_000_000,
        page_fault_rate=0.00001,  # 0.001%, matches report
    )

    # Trace with locality: mostly within a 50-page working set
    working_set = list(range(50))
    trace = []
    for _ in range(5000):
        if random.random() < 0.95:
            trace.append(random.choice(working_set))
        else:
            trace.append(random.randint(51, 5000))

    result = vms.run_trace(trace)
    import json
    print(json.dumps(result, indent=2))

    theoretical = VirtualMemorySystem.theoretical_emat(
        tlb_hit_ratio=0.97, tlb_time=1, page_table_time=100,
        mem_time=100, page_fault_rate=0.00001, page_fault_service_time=8_000_000
    )
    print("Theoretical EMAT (report formula):", theoretical, "cycles")


if __name__ == "__main__":
    demo()
